package com.example.gerenciadordepizzaria;

//comportamento base para outras classes
public interface Pizza {
    String getNome();
    double getPreco();
    String getTamanho();
    String getDescricao();
}
